var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var file_exports = {};
__export(file_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(file_exports);
var import_blobs = require("@netlify/blobs");
const handler = async (event) => {
  try {
    console.log("File handler called:", { method: event.httpMethod, path: event.path });
    if (event.httpMethod !== "GET") {
      return {
        statusCode: 405,
        body: JSON.stringify({ error: "Method not allowed" })
      };
    }
    const pathParts = event.path.split("/").filter((p) => p);
    const filename = pathParts[pathParts.length - 1];
    if (!filename) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Filename is required" })
      };
    }
    const store = (0, import_blobs.getStore)("uploads");
    let fileData = null;
    try {
      fileData = await store.get(filename);
      if (!fileData) {
        return {
          statusCode: 404,
          body: JSON.stringify({ error: "File not found" })
        };
      }
    } catch (e) {
      console.error("Error reading file from KV:", e.message);
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Failed to read file" })
      };
    }
    const binaryData = Buffer.from(fileData, "base64");
    let contentType = "application/octet-stream";
    if (filename.endsWith(".jpg") || filename.endsWith(".jpeg")) {
      contentType = "image/jpeg";
    } else if (filename.endsWith(".png")) {
      contentType = "image/png";
    } else if (filename.endsWith(".gif")) {
      contentType = "image/gif";
    } else if (filename.endsWith(".webp")) {
      contentType = "image/webp";
    }
    return {
      statusCode: 200,
      headers: {
        "Content-Type": contentType,
        "Cache-Control": "public, max-age=31536000"
      },
      body: binaryData.toString("base64"),
      isBase64Encoded: true
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: error.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
