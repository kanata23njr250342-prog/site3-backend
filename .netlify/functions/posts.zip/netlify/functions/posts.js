var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var posts_exports = {};
__export(posts_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(posts_exports);
var import_blobs = require("@netlify/blobs");
const POSTS_KEY = "posts";
const handler = async (event) => {
  const method = event.httpMethod;
  const pathParts = event.path.split("/").filter((p) => p);
  const postId = pathParts[pathParts.length - 1];
  const category = pathParts[pathParts.length - 1];
  console.log("Posts handler called:", { method, path: event.path, pathParts, postId, category });
  try {
    const store = (0, import_blobs.getStore)("posts");
    let body = null;
    if (event.body) {
      try {
        body = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
      } catch (e) {
        console.error("JSON parse error:", e.message);
        return {
          statusCode: 400,
          body: JSON.stringify({ error: "Invalid JSON" })
        };
      }
    }
    let posts = [];
    try {
      const stored = await store.get(POSTS_KEY);
      if (stored) {
        posts = JSON.parse(stored);
      }
    } catch (e) {
      console.error("Error reading posts from KV:", e.message);
      posts = [];
    }
    if (method === "GET" && category && !postId) {
      const categoryPosts = posts.filter((p) => p.category === category);
      return {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(categoryPosts)
      };
    }
    if (method === "POST" && !postId) {
      const newPost = {
        id: Date.now().toString(),
        ...body,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      posts.push(newPost);
      try {
        await store.set(POSTS_KEY, JSON.stringify(posts));
      } catch (e) {
        console.error("Error saving posts to KV:", e.message);
      }
      return {
        statusCode: 201,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newPost)
      };
    }
    if (method === "PUT" && postId) {
      const index = posts.findIndex((p) => p.id === postId);
      if (index !== -1) {
        posts[index] = {
          ...posts[index],
          ...body,
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        try {
          await store.set(POSTS_KEY, JSON.stringify(posts));
        } catch (e) {
          console.error("Error saving posts to KV:", e.message);
        }
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(posts[index])
        };
      }
      return {
        statusCode: 404,
        body: JSON.stringify({ error: "Post not found" })
      };
    }
    if (method === "DELETE" && postId) {
      const index = posts.findIndex((p) => p.id === postId);
      if (index !== -1) {
        posts.splice(index, 1);
        try {
          await store.set(POSTS_KEY, JSON.stringify(posts));
        } catch (e) {
          console.error("Error saving posts to KV:", e.message);
        }
        return {
          statusCode: 200,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ success: true })
        };
      }
      return {
        statusCode: 404,
        body: JSON.stringify({ error: "Post not found" })
      };
    }
    return {
      statusCode: 404,
      body: JSON.stringify({ error: "Not found" })
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: error.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
