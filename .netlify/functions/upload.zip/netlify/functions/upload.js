var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var upload_exports = {};
__export(upload_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(upload_exports);
var import_blobs = require("@netlify/blobs");
const FILES_KEY = "uploaded_files";
const handler = async (event) => {
  try {
    console.log("Upload handler called:", { method: event.httpMethod, path: event.path });
    if (event.httpMethod !== "POST") {
      return {
        statusCode: 405,
        body: JSON.stringify({ error: "Method not allowed" })
      };
    }
    if (!event.body) {
      console.error("No body provided");
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Request body is required" })
      };
    }
    let body = null;
    try {
      body = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
      console.log("Body type:", typeof event.body, "Parsed body:", body);
    } catch (e) {
      console.error("JSON parse error:", e.message);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Invalid JSON" })
      };
    }
    const { filename, data } = body;
    console.log("Upload data received:", { filename: filename ? "present" : "missing", dataSize: data ? data.length : 0 });
    if (!filename || !data) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "filename and data are required" })
      };
    }
    const store = (0, import_blobs.getStore)("uploads");
    try {
      await store.set(filename, data);
      console.log("File saved to KV:", filename);
    } catch (e) {
      console.error("Error saving file to KV:", e.message);
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Failed to save file" })
      };
    }
    const url = `/.netlify/functions/file/${filename}`;
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        success: true,
        url
      })
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: error.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
